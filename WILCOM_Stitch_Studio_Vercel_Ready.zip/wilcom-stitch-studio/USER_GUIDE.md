# Operator quick guide — WILCOM Stitch Studio

1. Open the installed/deployed website. Click **Import SVG** or drop your SVG onto the browser window. You can explore the **hummingbird** and **Lion** demos without live Wilcom access.
2. Use the **Select** arrow to click a shape on the real SVG canvas. If a shape is hidden by others, select it via the **Layers** list (topmost first). **Alt-click** focuses without changing an assignment.
3. In **01 Stitch types** choose **Tatami**, **Satin**, or **Ignore**, then click paths. Default is unreviewed, never silently ignored. For a confirmed bulk decision, **Ignore all unreviewed (confirm)** is available. **Run** remains locked until the production manual adapter supports it.
4. In **02 Stitch order**, click included paths in intended stitch sequence. In **Sequence**, use ↑/↓, drag-and-drop, or remove to change it. Combined Mode is OFF by default.
5. The **QA** panel reports unsupported SVG constructs, open contours, missing path IDs, unreviewed items and unfinished order. Only validated plans can be exported.
6. Click **Validate & export JSON** or **Download ZIP**. The latter contains exact original SVG bytes plus matching SHA-256-bound JSON, not an EMB file.
7. The project autosaves locally. Return via **Projects**. Use the bundle ZIP to back up the original SVG and plan (the browser's intermediate project states themselves are not included in the bundle).

## Canvas

- Mouse wheel: zoom at pointer
- Middle mouse drag, Shift+drag, Space+drag, or hand tool: pan
- `F`: fit design to available page
- `V`: select tool; `H`: hand/pan tool
- `T`, `S`, `I`: Tatami, Satin, Ignore
- `1`, `2`: stitch type and stitch order stages
- `Ctrl+Z` / `Ctrl+Shift+Z`: Undo / Redo
- Grid/Outline/Canvas: view-only toggles; exported source never changes

**Compatibility boundary:** This static web app is not connected to Windows or Wilcom. It only prepares the owner's choices for the existing native agent. Always run local dry-run and require separate approval before live execution.
