# WILCOM Stitch Studio

**Permanent, Vercel-ready manual SVG embroidery selection workspace** based on the attached Lion selector UX. The site is reusable for **any** new SVG, not one HTML per design.

## Features

- True SVG DOM canvas, with mouse-wheel zoom centered under the pointer, pan (hand tool, middle-click, Space+drag or Shift+drag), Fit, coordinate rulers (mm), 10-mm grid, outline mode, checkerboard page, selection bounding box/handles, and navigator mini-map.
- Original Lion-style workflow: **01 Stitch Types** → **02 Stitch Order**, Combined mode OFF by default; Tatami, Satin, Ignore. Run is visible but locked because the verified production manual adapter is not yet known to support Run.
- Layer panel (stack top-first) with all path IDs, color chips, search, filters, and selection from the list when objects are occluded on the canvas.
- Sequence panel: click to add, ↑/↓ to reorder, drag-and-drop, remove, Undo/Redo.
- Browser local-first project library with IndexedDB autosave. No online account or server is needed. Data remains in the same browser/profile/origin: clearing browser site data, changing domains/browsers, or using private browsing can remove it. Export the JSON + SVG bundle as backup.
- Real **SHA-256 of the original uploaded SVG bytes**, bound to exported manual-plan JSON; original source bytes are unchanged.
- XML/SVG static production checks for supported tags, unique IDs, solid RGB fills, path command whitelist, closed contours and manual order completeness. **Not** a replacement for local agent dry-run or self-intersection verification.
- Export the original SVG, fully validated manual-plan JSON, or both in a dependency-free ZIP. A mismatched imported JSON is refused.
- Included Hummingbird and Lion sample SVGs for web-UI exploration. Samples do **not** execute jobs or touch Wilcom. Neither sample is pre-assigned a stitch family/order.
- Malicious / unsupported SVG content is **not injected** into the DOM; preview is rebuilt from known `svg`, `g`, `path` data only. Unsupported document constructs are flagged as blockers. Import SVG only from trusted sources; this is browser-based sanitation, not a comprehensive security audit.

## Local development

Requires Node 18+ and Python 3 if running the optional local server scripts (no npm packages required).

```bash
npm run dev
```

Visit http://localhost:3000.

If `python` isn't available on Windows, use `py -m http.server 3000` from this directory instead.

To create the static build:

```bash
npm run build
```

This generates `dist/`.

## Deployment to Vercel

1. Unzip the project and put it in a GitHub repository.
2. Vercel → Add New → Project → Import Git Repository.
3. Framework Preset **Other**, Build Command **npm run build**, Output Directory **dist**, Install Command **leave empty**.
4. Deploy. Subsequent SVGs are uploaded **inside the website**; never rebuild the app for each new image.

Alternatively use Vercel CLI from this directory (`vercel`), then deploy production (`vercel --prod`) after preview verification. Vercel may require account authentication; the deployment is not performed for you.

**Persistence caution:** Projects are browser-local, not synchronized between devices, domains or private/incognito sessions. For long-term backups, export the ZIP bundle before clearing site data.

## Wilcom JSON contract

Exported plan has the established Lion-compatible label `wilcom_lion_manual_assignment_prototype_v1` and fields:

`schema`, `source_svg`, `source_sha256`, `combined_mode`, `artwork_path_count`, `selected_count`, `ignored_count`, `objects`, `execution_order`.

Each `objects[]` item has `{shape_id,include,stitch_type,stitch_order}`. Each included `execution_order[]` item has `{shape_id,order,stitch_type}` with contiguous 1..N order. Excluded items have false/null/null. JSON SHA-256 is computed on **exact original SVG bytes**, not the sanitized preview. The application preserves exact shape IDs and does not modify uploaded SVGs.

Only Tatami/Satin are production-enabled, based on the last inspected `wilcom/manual_plan.py` contract. This web app does NOT run Wilcom or guarantee local adapter compatibility without a real dry-run.

## Important limitations

- This is a **manual shape selection/sequence editor**, not an SVG node/geometry editor or digitizer. Canvas handles show bounds and selection; they do not alter the original path geometry. This is intentional to preserve source SHA and plan binding.
- Unsupported SVG elements/transforms, missing/duplicate IDs, invalid fills, open contours, or arc path commands block final JSON export. Fix the SVG using a vector editor before importing.
- Browser syntax validation cannot guarantee the geometry is stitchable, non-self-intersecting, or free of hidden overlaps. Local agent dry-run is required and live execution requires separate owner approval.
- App is a static site, does not provide Google login, cloud sync, server-side uploads, or remote Wilcom control. Hosting is Vercel-ready with **zero external runtime dependencies**.

## Keyboard and mouse

`V` Select, `H` Hand/Pan, `T` Tatami, `S` Satin, `I` Ignore, `1` Types, `2` Order, `F` Fit, `Ctrl+Z` Undo, `Ctrl+Shift+Z` Redo, Mousewheel Zoom, Space/Shift/Middle Drag Pan, Alt-click path/list to focus only.
