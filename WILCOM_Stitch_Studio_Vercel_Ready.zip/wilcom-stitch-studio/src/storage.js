const DB_NAME='wilcom-stitch-studio-v1';
const STORE='projects';
let dbPromise;
function db(){
  if(!dbPromise)dbPromise=new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,1);
    req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE,{keyPath:'id'});};
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
  return dbPromise;
}
function request(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
export async function allProjects(){const d=await db();return request(d.transaction(STORE,'readonly').objectStore(STORE).getAll());}
export async function getProject(id){const d=await db();return request(d.transaction(STORE,'readonly').objectStore(STORE).get(id));}
export async function saveProject(project){const d=await db();return request(d.transaction(STORE,'readwrite').objectStore(STORE).put(project));}
export async function deleteProject(id){const d=await db();return request(d.transaction(STORE,'readwrite').objectStore(STORE).delete(id));}
