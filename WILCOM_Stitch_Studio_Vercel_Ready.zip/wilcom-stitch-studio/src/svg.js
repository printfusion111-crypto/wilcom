const NS='http://www.w3.org/2000/svg';
const allowedTags=new Set(['svg','g','path']);
const supportedCommands=new Set('MmLlHhVvCcSsQqTtZz');
const basicPaint=/^#[0-9a-fA-F]{6}$/;
const illegalAttrs=new Set(['style','class','transform','opacity','fill-opacity','stroke-opacity','filter','mask','clip-path']);
const utf8=new TextEncoder();
export function shaHex(bytes){return crypto.subtle.digest('SHA-256',bytes).then(buf=>Array.from(new Uint8Array(buf),b=>b.toString(16).padStart(2,'0')).join(''));}
export function parseSvg(text){
 if(text.length>16*1024*1024)throw new Error('SVG is larger than the 16 MB editor limit.');
 if(/<!DOCTYPE|<!ENTITY/i.test(text))throw new Error('SVG DTD/entity declarations are not allowed.');
 const doc=new DOMParser().parseFromString(text,'image/svg+xml');
 if(doc.querySelector('parsererror')||doc.documentElement?.localName!=='svg'||doc.documentElement?.namespaceURI!==NS)throw new Error('Invalid SVG XML or SVG namespace.');
 const root=doc.documentElement,checks=[],pathData=[],ids=new Set(),colors=new Set();
 const add=(status,title,detail)=>checks.push({status,title,detail});
 const vbText=root.getAttribute('viewBox')||'';
 const vbValues=vbText.trim().split(/[\s,]+/).map(Number);
 const validViewBox=vbValues.length===4&&vbValues.every(Number.isFinite)&&vbValues[2]>0&&vbValues[3]>0;
 const vb=validViewBox?{x:vbValues[0],y:vbValues[1],w:vbValues[2],h:vbValues[3]}:null;
 add(validViewBox?'pass':'fail','SVG viewBox',validViewBox?vbText:'Missing or invalid numeric viewBox.');
 const invalidTags=[];const riskyAttrs=[];let externalRef=false;
 for(const el of doc.querySelectorAll('*')){
   const tag=el.localName;
   if(!allowedTags.has(tag))invalidTags.push(`<${tag}>`);
   for(const attr of [...el.attributes]){
     const lower=attr.name.toLowerCase(),value=attr.value;
     if(lower.startsWith('on')||illegalAttrs.has(lower)||lower==='href'||lower.endsWith(':href')||/url\s*\(/i.test(value))riskyAttrs.push(`${tag}:${lower}`);
     if(!lower.startsWith('xmlns')&&(/https?:\/\//i.test(value)||/data:/i.test(value)))externalRef=true;
     if(lower.startsWith('stroke')&&lower!=='stroke' || lower==='stroke'&&value.trim().toLowerCase()!=='none')riskyAttrs.push(`${tag}:${lower}`);
   }
 }
 add(invalidTags.length===0?'pass':'fail','Supported SVG elements',invalidTags.length?`Unsupported: ${[...new Set(invalidTags)].slice(0,8).join(', ')}${invalidTags.length>8?'…':''}`:'Only svg / g / path.');
 add(riskyAttrs.length===0&&!externalRef?'pass':'fail','Safe production attributes',riskyAttrs.length?`Unsupported: ${[...new Set(riskyAttrs)].slice(0,8).join(', ')}`:externalRef?'External or embedded references found.':'No scripts, event handlers, transforms, CSS, or external assets detected.');
 const pathEls=[...root.querySelectorAll('path')];let invalidIds=0,invalidFills=0,invalidCommands=0,notClosed=0,emptyD=0,strokes=0;
 for(let index=0;index<pathEls.length;index++){
   const el=pathEls[index],id=el.getAttribute('id')||'',fill=el.getAttribute('fill')||'',d=el.getAttribute('d')||'';
   const idValid=!!id&&!ids.has(id);if(!idValid)invalidIds++;ids.add(id);
   if(!basicPaint.test(fill))invalidFills++;else colors.add(fill.toUpperCase());
   const commands=d.match(/[a-zA-Z]/g)||[];
   const invalid=commands.some(cmd=>!supportedCommands.has(cmd));if(invalid)invalidCommands++;
   if(!/z\s*$/i.test(d.trim()))notClosed++;
   if(!d.trim())emptyD++;
   if(el.hasAttribute('stroke')&&el.getAttribute('stroke')!=='none')strokes++;
   pathData.push({id,fill:fill.toUpperCase(),d,index,valid:idValid&&basicPaint.test(fill)&&!invalid});
 }
 add(pathEls.length>0?'pass':'fail','Selectable path objects',`${pathEls.length} SVG path${pathEls.length===1?'':'s'} found.`);
 add(invalidIds===0?'pass':'fail','Unique path IDs',invalidIds?`${invalidIds} missing/duplicate path ID(s).`:'All path IDs are unique and non-empty.');
 add(invalidFills===0?'pass':'fail','Solid RGB fills',invalidFills?`${invalidFills} paths need direct fill="#RRGGBB".`:`${colors.size} distinct RGB colors.`);
 add(invalidCommands===0?'pass':'fail','Supported path commands',invalidCommands?`${invalidCommands} path(s) contain unsupported commands (e.g., A/a arcs).`:'All path commands are in the supported whitelist.');
 add(notClosed===0&&emptyD===0?'pass':'fail','Closed contours',`${notClosed} paths do not end with Z/z; ${emptyD} empty paths. Browser check is syntax-level only.`);
 add(strokes===0?'pass':'fail','Stroke-only geometry',strokes?`${strokes} path(s) have SVG stroke attributes requiring conversion to filled contours.`:'No explicit painted strokes on paths.');
 add('info','Topology and physical suitability','Self-intersections, overlapping regions, valid native fill topology and minimum feature width are NOT VERIFIED here; local production dry-run required.');
 const widthMM=parseLength(root.getAttribute('width'));const heightMM=parseLength(root.getAttribute('height'));
 add(widthMM&&heightMM?'pass':'warn','Physical dimensions',widthMM&&heightMM?`${trim(widthMM)} × ${trim(heightMM)} mm`: 'SVG width/height are not both absolute physical lengths in recognized units.');
 const blockers=checks.filter(x=>x.status==='fail');
 // Reconstruct a SAFE visual preview with only known production attrs; never inject uploaded HTML directly.
 const preview=document.createElementNS(NS,'svg');preview.setAttribute('xmlns',NS);if(vb)preview.setAttribute('viewBox',vbText);preview.setAttribute('preserveAspectRatio','xMidYMid meet');
 for(const p of pathData){if(!p.d)continue;const clean=document.createElementNS(NS,'path');clean.setAttribute('d',p.d);clean.setAttribute('fill',basicPaint.test(p.fill)?p.fill:'#9CA3AF');clean.setAttribute('data-wilcom-path',p.id);preview.appendChild(clean);}
 return {text,vb,paths:pathData,checks,colors:[...colors],widthMM,heightMM,blockers,previewXML:new XMLSerializer().serializeToString(preview),preview};
}
function parseLength(s){if(!s)return null;const m=s.match(/^\s*(\d+(?:\.\d+)?)\s*(mm|cm|in|pt|px)\s*$/i);if(!m)return null;const n=Number(m[1]);if(!(n>0))return null;const f={mm:1,cm:10,in:25.4,pt:25.4/72,px:25.4/96}[m[2].toLowerCase()];return n*f;}
function trim(n){return Number(n.toFixed(2));}
export function producePlan(project, parsed){const ids=parsed.paths.map(p=>p.id),order=project.order.filter(x=>project.assignments[x]==='tatami'||project.assignments[x]==='satin');return {schema:'wilcom_lion_manual_assignment_prototype_v1',source_svg:project.fileName,source_sha256:project.hash,combined_mode:!!project.combined,artwork_path_count:ids.length,selected_count:ids.filter(id=>['tatami','satin'].includes(project.assignments[id])).length,ignored_count:ids.filter(id=>!['tatami','satin'].includes(project.assignments[id])).length,objects:ids.map(id=>({shape_id:id,include:['tatami','satin'].includes(project.assignments[id]),stitch_type:['tatami','satin'].includes(project.assignments[id])?project.assignments[id]:null,stitch_order:order.includes(id)?order.indexOf(id)+1:null})),execution_order:order.map((id,i)=>({shape_id:id,order:i+1,stitch_type:project.assignments[id]}))};}
export function validateAssignment(project,parsed){const a=project.assignments||{};const ids=parsed.paths.map(p=>p.id);const selected=ids.filter(id=>a[id]==='tatami'||a[id]==='satin');const unreviewed=ids.filter(id=>!['tatami','satin','ignore'].includes(a[id]));const ordered=(project.order||[]).filter(id=>selected.includes(id));const wrongOrder=ordered.length!==selected.length||new Set(ordered).size!==ordered.length||project.order.length!==ordered.length;const checks=[...parsed.checks,{status:selected.length===0?'fail':'pass',title:'At least one included path',detail:selected.length?`${selected.length} included native object candidate(s).`:'Choose Tatami or Satin for at least one shape.'},{status:unreviewed.length?'fail':'pass',title:'Owner reviewed all paths',detail:unreviewed.length?`${unreviewed.length} path(s) remain unreviewed. Assign Tatami, Satin or Ignore.`:'Every path has an explicit decision.'},{status:wrongOrder?'fail':'pass',title:'Complete sewing order',detail:wrongOrder?`${selected.length} included, ${ordered.length} validly ordered. Finish the sequence.`:`All ${selected.length} included paths have unique contiguous order.`},{status:'pass',title:'Source fingerprint',detail:`SHA-256 bound to the unmodified original SVG (${project.hash?.slice(0,16) || '—'}…).`}];return {checks,ready:!checks.some(x=>x.status==='fail'),unreviewed,selected,ordered};}
export function validateImportedPlan(plan,project,parsed){if(!plan||typeof plan!=='object'||plan.source_sha256!==project.hash)throw Error('SVG SHA-256 fingerprint mismatch. Load the original matching design.');if(plan.source_svg!==project.fileName)throw Error('Source SVG filename does not match the active artwork.');if(!Array.isArray(plan.objects)||!Array.isArray(plan.execution_order))throw Error('Malformed plan: missing objects or execution_order.');const ids=parsed.paths.map(p=>p.id),idSet=new Set(ids),seen=new Set(),assignments={};if(plan.objects.length!==ids.length)throw Error('Object list length mismatch.');for(const x of plan.objects){if(!x||typeof x.shape_id!=='string'||!idSet.has(x.shape_id)||seen.has(x.shape_id))throw Error('Duplicate or unknown shape ID in plan.');seen.add(x.shape_id);if(x.include===true){if(!['tatami','satin'].includes(x.stitch_type))throw Error(`Unsupported type for ${x.shape_id}.`);assignments[x.shape_id]=x.stitch_type;}else if(x.include===false){if(x.stitch_type!==null||x.stitch_order!==null)throw Error(`Excluded object ${x.shape_id} has inconsistent fields.`);assignments[x.shape_id]='ignore';}else throw Error('Invalid include boolean.');}
const selected=ids.filter(id=>['tatami','satin'].includes(assignments[id]));if(selected.length!==plan.execution_order.length||selected.length!==plan.selected_count||ids.length-selected.length!==plan.ignored_count||plan.artwork_path_count!==ids.length)throw Error('Plan counts disagree with SVG or execution order.');const order=[];for(const row of plan.execution_order){if(!selected.includes(row.shape_id)||row.order!==order.length+1||row.stitch_type!==assignments[row.shape_id]||order.includes(row.shape_id))throw Error('Invalid execution order sequence.');order.push(row.shape_id);}for(const o of plan.objects){const actual=order.indexOf(o.shape_id);if(o.include&&(o.stitch_order!==actual+1))throw Error('Object order mismatch.');}return {assignments,order,combined:!!plan.combined_mode};}
export function safeFilename(name){return (name||'design').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,100);}
export const encoder=utf8;
