// Dependency-free ZIP archive, STORE method (no compression). Suitable for SVG + JSON plans.
const text = new TextEncoder();
const crcTable=(()=>{const t=new Uint32Array(256);for(let i=0;i<256;i++){let c=i;for(let j=0;j<8;j++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);t[i]=c>>>0;}return t;})();
function crc32(bytes){let c=0xffffffff;for(const byte of bytes)c=crcTable[(c^byte)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
function u16(v){return [v&255,(v>>>8)&255];}function u32(v){return [v&255,(v>>>8)&255,(v>>>16)&255,(v>>>24)&255];}
function bytesOf(value){return value instanceof Uint8Array?value:typeof value==='string'?text.encode(value):new Uint8Array(value);}
export function buildZip(entries){
 let offset=0;const parts=[],central=[];
 for(const {name,data} of entries){
   const nameBytes=text.encode(name),body=bytesOf(data),crc=crc32(body),len=body.length;
   const local=new Uint8Array([0x50,0x4b,0x03,0x04,...u16(20),...u16(0x800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(len),...u32(len),...u16(nameBytes.length),...u16(0)]);
   parts.push(local,nameBytes,body);
   const cd=new Uint8Array([0x50,0x4b,0x01,0x02,...u16(20),...u16(20),...u16(0x800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(len),...u32(len),...u16(nameBytes.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset)]);
   central.push(cd,nameBytes);
   offset+=local.length+nameBytes.length+len;
 }
 let cdSize=0;for(const a of central)cdSize+=a.length;
 const count=entries.length;
 const end=new Uint8Array([0x50,0x4b,0x05,0x06,...u16(0),...u16(0),...u16(count),...u16(count),...u32(cdSize),...u32(offset),...u16(0)]);
 return new Blob([...parts,...central,end],{type:'application/zip'});
}
