import {cp,mkdir,rm,stat} from 'node:fs/promises';
const files=['index.html','styles.css','src','assets','examples'];
await rm('dist',{recursive:true,force:true});await mkdir('dist',{recursive:true});
for(const path of files){await cp(path,`dist/${path}`,{recursive:true});}
await stat('dist/index.html');
console.log('Production build complete: dist/ (static Vercel deployment, zero npm runtime dependencies).');
