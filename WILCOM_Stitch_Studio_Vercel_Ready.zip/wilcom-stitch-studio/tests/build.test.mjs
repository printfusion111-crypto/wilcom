import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';

test('Vercel output and source entrypoints exist',async()=>{
  for (const file of ['index.html','src/main.js','src/svg.js','src/storage.js','src/zip.js','examples/hummingbird.svg','examples/lion.svg','dist/index.html','vercel.json']){
    assert.ok((await stat(file)).size>0,file);
  }
  const text=await readFile('src/svg.js','utf8');
  assert.ok(text.includes('wilcom_lion_manual_assignment_prototype_v1'));
  const svg=await readFile('examples/hummingbird.svg');
  assert.equal(svg.length>0,true);
  assert.equal(createHash('sha256').update(svg).digest('hex').length,64);
});
