import test from 'node:test';
import assert from 'node:assert/strict';
import {buildZip} from '../src/zip.js';

test('ZIP export writes local records, contents and central directory',async()=>{
  const contents='{"selected_count":2}';
  const zip=buildZip([{name:'design.svg',data:'<svg/>'},{name:'plan.json',data:contents}]);
  const bytes=new Uint8Array(await zip.arrayBuffer());
  assert.equal(zip.type,'application/zip');
  assert.deepEqual([...bytes.slice(0,4)],[0x50,0x4b,0x03,0x04]);
  const text=new TextDecoder().decode(bytes);
  assert.ok(text.includes('<svg/>'));
  assert.ok(text.includes(contents));
  assert.deepEqual([...bytes.slice(-22,-18)],[0x50,0x4b,0x05,0x06]);
  assert.equal(bytes[bytes.length-14],2);
});
