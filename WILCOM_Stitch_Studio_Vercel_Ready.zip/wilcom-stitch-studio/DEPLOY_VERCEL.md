# Deploy WILCOM Stitch Studio to Vercel

## Fastest route (GitHub + Vercel)

1. Extract `WILCOM_Stitch_Studio_Vercel_Ready.zip` to a folder on your PC.
2. Create a GitHub repository, and upload the **contents** of `wilcom-stitch-studio` into the repository root (keep `package.json`, `vercel.json`, `index.html`, `src/`, `examples/`, `styles.css`, and `scripts/` together).
3. Visit [vercel.com/new](https://vercel.com/new), connect GitHub and import that repository.
4. Set **Framework Preset: Other**, **Build Command: `npm run build`**, **Output Directory: `dist`**. There are **no npm dependencies**.
5. Deploy. Bookmark the permanent Vercel URL. Upload future SVGs **inside the deployed website**, not via GitHub.

## Alternative: Vercel CLI

After extracting the project, open PowerShell in the project folder:

```powershell
npm run build
npx vercel
npx vercel --prod
```

These commands require you to authenticate to Vercel and authorize the deployment. They have not been run in this environment.

## Workflow

Open the site → `Import SVG` → Stage 01 `Stitch types` → Stage 02 `Stitch order` → QA → `Validate & export JSON` or `Download ZIP`.

The ZIP contains the **unaltered** original SVG and its SHA-256-bound manual-plan JSON. Use the existing local Wilcom agent to dry-run the exported pair **only after separate authorization**.

## What is saved where?

Projects autosave to IndexedDB in the browser that opens the website. No backend uploads are performed. Clearing site data, changing browsers, accessing another URL or private browsing can remove the local projects; export the ZIP as a backup. A Vercel URL does not by itself synchronize project data across devices.

## Intended limits

This is an embroidery **manual assignment** vector workspace, not a full SVG node editor. Canvas pan/zoom, mm rulers, selection boxes, grid, outline mode, and minimap do not change geometry or the SVG's SHA-256. The validator catches common markup and assignment problems but **cannot certify native geometry or stitch-out quality**.
